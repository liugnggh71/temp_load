echo exit | /u02/app/oracle/product/12.1.0/dbhome_3/bin/sqlplus "/as sysdba" @/opt/oracle.ahf/tfa/resources/sql/srdc_db_lfsdiag.sql
