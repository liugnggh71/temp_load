/u02/app/oracle/product/12.1.0/dbhome_13/bin/sqlplus "/as sysdba" << EOF1
@/opt/oracle.ahf/tfa/resources/sql/db_feature_usage.sql

EOF1
